# completed code-katas

array_diff (6 kyu)
module - array_diff.py
test - test_array_diff.py
url - http://www.codewars.com/kata/array-dot-diff/python

sum_of_numbers (7 kyu)
module - sum_of_numbers.py
test - test_sum_of_numbers.py
url - https://www.codewars.com/kata/55f2b110f61eb01779000053

your order, please
score = 6