# completed code-katas

array_diff (6 kyu)
module - array_diff.py
test - test_array_diff.py
url - http://www.codewars.com/kata/array-dot-diff/python

sum_of_numbers (7 kyu)
module - sum_of_numbers.py
test - test_sum_of_numbers.py
url - https://www.codewars.com/kata/55f2b110f61eb01779000053

your order, please (6 kyu)
module - your_order_please.py
test - test_your_order_please.py
url - https://www.codewars.com/kata/your-order-please/python

remove the minimum (7 kyu)
module - remove_the_minimum.py
test - test_remove_the_minimum.py
url - https://www.codewars.com/kata/remove-the-minimum/python

replace with alphabet position (6 kyu)
module - replace_with_alphabet_position.py
test - test_replace_with_alphabet_position.py
url -https://www.codewars.com/kata/replace-with-alphabet-position/python

find the pairity outlier (6 kyu)
module - find_outlier.py
test - test_find_outlier.py
url - https://www.codewars.com/kata/find-the-parity-outlier/python

score = 20

